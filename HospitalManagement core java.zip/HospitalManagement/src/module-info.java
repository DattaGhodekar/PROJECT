/**
 * 
 */
/**
 * @author user5
 *
 */
module HospitalManagement {
}