package org.example.main;

import java.util.ArrayList;

class PatientRecord {
    private Patient patient;
    private ArrayList<MedicalRecord> medicalRecords;
    
    public PatientRecord(Patient patient) {
        this.patient = patient;
        medicalRecords = new ArrayList<>();
    }
    
    public Patient getPatient() {
        return patient;
    }
    
    public void addMedicalRecord(MedicalRecord record) {
        medicalRecords.add(record);
    }
    
    public ArrayList<MedicalRecord> getMedicalRecords() {
        return medicalRecords;
    }
}
