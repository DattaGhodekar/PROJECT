package org.example.main;

import java.util.ArrayList;

class Hospital {
    private ArrayList<PatientRecord> patientRecords;
    
    public Hospital() {
        patientRecords = new ArrayList<>();
    }
    
    public void addPatientRecord(PatientRecord record) {
        patientRecords.add(record);
    }
    
    public ArrayList<PatientRecord> getPatientRecords() {
        return patientRecords;
    }
}
