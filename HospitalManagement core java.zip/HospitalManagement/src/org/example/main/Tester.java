package org.example.main;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class Tester {
    
	public static void main(String[] args) {
        Hospital hospital = new Hospital();
        HospitalManager manager = new HospitalManager(hospital);
        Scanner scanner = new Scanner(System.in);

        int choice = 0;
        do {
            System.out.println("Choose an option:");
            System.out.println("1. Add new patient record");
            System.out.println("2. Add medical record for a patient");
            System.out.println("3. Get patient record");
            System.out.println("4. Get medical records for a patient");
            System.out.println("5. Exit");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	try {
                    System.out.println("Enter patient name:");
                    String name = scanner.nextLine();
                    System.out.println("Enter patient age:");
                    int age = scanner.nextInt();
                    scanner.nextLine(); 
                    String gender;
                    System.out.println("Enter patient gender (alphabetic only):");
                    gender = scanner.nextLine();
                    if (!gender.matches("[a-zA-Z]+")) {
                        System.out.println("Invalid gender value entered. Program terminated.");
                        System.exit(0);
                    }
                    
                    System.out.println("Enter patient address:");
                    String address = scanner.nextLine();
                    Patient patient = new Patient(name, age, gender, address);
                    PatientRecord patientRecord = new PatientRecord(patient);
                    manager.addPatientRecord(patientRecord);
                    System.out.println("Patient record added successfully.");
                    break;
                	}
                	catch(Exception e)
                	{
                		System.out.println("Invalid input");
                		return;
                	}
                case 2:
                    System.out.println("Enter patient name:");
                    String patientName = scanner.nextLine();
                    System.out.println("Enter medical record date (DD/MM/YYYY):");
                    //String dateStr =
                    scanner.nextLine();
                    System.out.println("Enter doctor name:");
                    String doctorName = scanner.nextLine();
                    System.out.println("Enter diagnosis:");
                    String diagnosis = scanner.nextLine();
                    System.out.println("Enter treatment:");
                    String treatment = scanner.nextLine();
                    try {
				          LocalDate local= LocalDate.now();
					      MedicalRecord medicalRecord = new MedicalRecord(local, doctorName, diagnosis, treatment);
                          manager.addMedicalRecord(patientName, medicalRecord);
                          System.out.println("Medical record added successfully.");
                    } catch (Exception e) {
                        System.out.println("Invalid date format. Medical record not added.");
                    }
                    break;
                case 3:
                    System.out.println("Enter patient name:");
                    String patientName2 = scanner.nextLine();
                    
                    PatientRecord record = manager.getPatientRecord(patientName2);
                    if (record != null) {
                        Patient patient2 = record.getPatient();
                        System.out.println("Name: " + patient2.getName());
                        System.out.println("Age: " + patient2.getAge());
                        System.out.println("Gender: " + patient2.getGender());
                        System.out.println("Address: " + patient2.getAddress());
                    }
                    break;
                case 4:
                    System.out.println("Enter patient name:");
                    String patientName3 = scanner.nextLine();
                    ArrayList<MedicalRecord> medicalRecords = manager.getPatientMedicalRecords(patientName3);
                    if (medicalRecords != null) {
                        System.out.println("Medical records for " + patientName3 + ":");
                        for (MedicalRecord record2 : medicalRecords) {
                            System.out.println("Date: " + record2.getDate());
                            System.out.println("Doctor name: " + record2.getDoctorName());
                            System.out.println("Diagnosis: " + record2.getDiagnosis());
                            System.out.println("Treatment: " + record2.getTreatment());
                            System.out.println();
                        }
                    }
                    break;
                case 5:
                    System.out.println("Exit  ");
                    break;
                default:
                    System.out.println("Invalid choice.");
                    break;
            }

        } while (choice != 5);
        scanner.close();
    }
}