package org.example.main;

import java.util.ArrayList;

class HospitalManager {
    private Hospital hospital;
    
    public HospitalManager(Hospital hospital) {
        this.hospital = hospital;
    }
    
    public void addPatientRecord(PatientRecord record) {
        hospital.addPatientRecord(record);
    }
    
    public void addMedicalRecord(String patientName, MedicalRecord record) {
        PatientRecord patientRecord = getPatientRecord(patientName);
        if (patientRecord != null) {
            patientRecord.addMedicalRecord(record);
        } else {
            System.out.println("Patient not found.");
        }
    }
    
    public PatientRecord getPatientRecord(String patientName) {
        for (PatientRecord record : hospital.getPatientRecords()) {
            if (record.getPatient().getName().equals(patientName)) {
                return record;
            }
        }
        return null;
    }
    
    public ArrayList<MedicalRecord> getPatientMedicalRecords(String patientName) {
        PatientRecord patientRecord = getPatientRecord(patientName);
        if (patientRecord != null) {
            return patientRecord.getMedicalRecords();
        } else {
            System.out.println("Patient not found.");
            return null;
        }
    }
}