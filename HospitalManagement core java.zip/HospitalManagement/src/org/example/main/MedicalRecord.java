package org.example.main;

import java.time.LocalDate;



class MedicalRecord {
    private LocalDate date;
    private String doctorName;
    private String diagnosis;
    private String treatment;
    
    public MedicalRecord(LocalDate date, String doctorName, String diagnosis, String treatment) {
        this.date = date;
        this.doctorName = doctorName;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
    }
    
    public LocalDate getDate() {
        return date;
    }
    
    public String getDoctorName() {
        return doctorName;
    }
    
    public String getDiagnosis() {
        return diagnosis;
    }
    
    public String getTreatment() {
        return treatment;
    }
}
